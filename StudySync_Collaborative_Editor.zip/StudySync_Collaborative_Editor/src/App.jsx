import { useEffect, useMemo, useRef, useState } from "react";
import { io } from "socket.io-client";
const socket = io();

export default function App() {
  const [name,setName]=useState("");
  const [docId,setDocId]=useState("study-room");
  const [joined,setJoined]=useState(false);
  const [content,setContent]=useState("Welcome to StudySync! ✨\n\nThis is your shared study space.\n\n• Write your notes here.\n• Ask a friend to join using the same document ID.\n• Your changes will appear for everyone in real time.\n\nHappy studying!");
  const [users,setUsers]=useState([]);
  const [status,setStatus]=useState("Not saved yet");
  const [storage,setStorage]=useState("Waiting for document");
  const [connection,setConnection]=useState("Connecting…");
  const [dark,setDark]=useState(false);
  const [error,setError]=useState("");
  const timer=useRef(null);
  const joinedInfo=useRef(null);
  const words=useMemo(()=>content.trim()?content.trim().split(/\s+/).length:0,[content]);

  useEffect(()=>{
    const connect=()=>{setConnection("Connected");if(joinedInfo.current)socket.emit("join-document",joinedInfo.current);};
    const disconnect=()=>{setConnection("Reconnecting…");setStatus("Connection interrupted");};
    const joinedEvent=()=>{setJoined(true);setError("");};
    const receive=({content:txt,storage:mode})=>{setContent(txt||"");setStorage(mode==="mongodb"?"MongoDB connected":"Temporary memory mode");setStatus("All changes saved");};
    const remote=({content:txt,username})=>{setContent(txt);setStatus(`${username} edited this document`);};
    const online=list=>setUsers(list||[]);
    const saved=({storage:mode})=>{setStatus("Saved just now");setStorage(mode==="mongodb"?"Saved to MongoDB":"Saved temporarily (MongoDB not connected)");};
    const appError=msg=>setError(msg);
    socket.on("connect",connect);socket.on("disconnect",disconnect);
    socket.on("joined-document",joinedEvent);socket.on("document-content",receive);
    socket.on("document-change",remote);socket.on("online-users",online);
    socket.on("document-saved",saved);socket.on("app-error",appError);
    return ()=>{socket.off("connect",connect);socket.off("disconnect",disconnect);
      socket.off("joined-document",joinedEvent);socket.off("document-content",receive);
      socket.off("document-change",remote);socket.off("online-users",online);
      socket.off("document-saved",saved);socket.off("app-error",appError);clearTimeout(timer.current);};
  },[]);

  function join(e){
    e.preventDefault();
    const cleanName=name.trim().slice(0,24);
    const cleanId=docId.trim().toLowerCase().replace(/[^a-z0-9-]/g,"-").slice(0,40);
    if(!cleanName||!cleanId){setError("Please enter your name and a document ID.");return;}
    joinedInfo.current={username:cleanName,documentId:cleanId};
    setName(cleanName);setDocId(cleanId);socket.emit("join-document",joinedInfo.current);
  }
  function edit(e){
    const value=e.target.value;setContent(value);setStatus("Unsaved changes…");
    clearTimeout(timer.current);
    timer.current=setTimeout(()=>{
      if(socket.connected&&joinedInfo.current)socket.emit("edit-document",{content:value});
      else setStatus("Offline — changes are not synced");
    },650);
  }
  function leave(){
    clearTimeout(timer.current);joinedInfo.current=null;socket.disconnect();
    setJoined(false);setUsers([]);setConnection("Disconnected");socket.connect();
  }
  async function copyId(){
    try{await navigator.clipboard.writeText(docId);setStatus("Document ID copied!");}
    catch{setStatus(`Share this ID: ${docId}`);}
  }

  if(!joined)return <div className={`shell ${dark?"dark":""}`}>
    <main className="login-layout">
      <section className="login-card">
        <div className="brand-mark">S</div><p className="eyebrow">STUDY TOGETHER, ACHIEVE TOGETHER</p>
        <h1>Study<span>Sync</span></h1>
        <p className="intro">A simple shared space for notes, assignments and group study.</p>
        <form onSubmit={join}>
          <label htmlFor="name">Your name</label><input id="name" value={name} onChange={e=>setName(e.target.value)} placeholder="Enter your name" maxLength="24"/>
          <label htmlFor="doc">Document ID</label><input id="doc" value={docId} onChange={e=>setDocId(e.target.value)} placeholder="e.g. dbms-unit-3" maxLength="40"/>
          <p className="hint">Friends who enter the same document ID can edit with you.</p>
          {error&&<p className="error">{error}</p>}
          <button className="primary" type="submit">Open shared document →</button>
        </form>
        <p className="foot"><i/> Real-time collaboration</p>
      </section>
      <aside className="welcome"><div className="paper-art"><div className="sheet back"></div><div className="sheet front"><b></b><i></i><i></i><strong></strong><i></i></div><span>✦</span></div>
        <h2>Your team's ideas,<br/>in one place.</h2><p>Write together. See updates instantly. Keep your study notes organised.</p>
        <div className="pills"><span>✍️ Live editing</span><span>👥 Online members</span><span>💾 Auto-save</span></div>
      </aside>
    </main>
  </div>;

  return <div className={`shell editor-shell ${dark?"dark":""}`}>
    <header className="topbar"><div className="brand-lock"><div className="brand-mark mini">S</div><div><b>StudySync</b><small>Collaborative workspace</small></div></div>
      <div className="top-actions"><span className="connection"><i className={connection==="Connected"?"ok":""}/>{connection}</span>
        <button className="light-button" onClick={()=>setDark(v=>!v)} type="button">{dark?"☀️":"🌙"}</button>
        <button className="light-button" onClick={leave} type="button">Leave</button></div>
    </header>
    <main className="workspace">
      <div className="doc-heading"><div><p className="eyebrow">SHARED DOCUMENT</p><h1>{docId.replace(/-/g," ")}</h1><p className="sub">Your team's shared study notes</p></div>
        <button className="share" onClick={copyId} type="button">↗ Share document ID</button></div>
      <section className="collab"><div className="people"><div className="avatars">{users.slice(0,5).map((u,i)=><span key={u.username+i} title={u.username}>{u.username[0].toUpperCase()}</span>)}</div>
          <div><b>{users.length} online</b><small>{users.map(u=>u.username).join(", ")||"Waiting for collaborators"}</small></div></div>
        <div className="saved"><span>✓</span><div><b>{status}</b><small>{storage}</small></div></div></section>
      <section className="editor"><div className="editor-head"><b>✎ DOCUMENT EDITOR</b><span><i/> LIVE SYNC</span></div>
        <textarea value={content} onChange={edit} placeholder="Start writing your shared notes…" aria-label="Shared document editor"/>
        <div className="editor-foot"><span>Share the same document ID with your teammates.</span><span>{words} words · {content.length} characters</span></div></section>
      {error&&<p className="error">{error}</p>}
      <p className="privacy">🔒 Anyone with this document ID can join this demo workspace. Do not use private information.</p>
    </main>
  </div>;
}
